const Home = () => {

    return (

        <>
            Home Component
        </>

    )

}

export default Home;